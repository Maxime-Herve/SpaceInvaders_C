/*!
* \file spaceI.c
* \author Maxime HERVE et Yann MORIN <maximeholga@gmail.com>
* \version 2.0
* \date 30/11/2020
* \brief Fonction servant au programme lanceur_spaceI.c
* \remarks Spécification présente dans spaceI.h
* 
* 
* 
*/


/*! Importation de librairies*/
#include "spaceI.h"


s_vaisseau initialiserVaisseau() { //constructeur vaisseau
    /**
    *Initialisation d'un vaisseau
    */
    s_vaisseau v;
    v.posX = LARGEUR / 2;
    v.cel = VITESSEVS;      
    v.tir = 's';
    v.aTire = 0;
    return v;
}

s_alien initialiserAlien(int x, int y){  //constructeur alien
    /**
    *Initialisation d'un alien
    */
    s_alien s; 
    s.posX = x;
    s.posY = y;
    s.cel = VITESSEAL;
    s.pv = NBVIEAL;

    /**
    *Retourne l'alien
    */
    return s;
} 

int initialiserAliensV2(tab_aliens as, infopartie info) {

    /**
    *Initialisation d'un tableau d'aliens, hauteur minimum 3 ( pour laisser la place au affichage comme le score
    */
    int i, x, y = 3, reste;

    /**
    *Calcul permettant la création du bon nombre d'aliens en fonction du nombre d'aliens prédéfini et  du niveau
    */
    info.nombreal = NBALIENS*info.level;

    /**
    *Condition mettant automatiquement les aliens au centre du plateau quelque soit leurs nombres 
    *ou le nombre par lignes défini dans ALIENSPARLIGNE
    */
    if ( info.nombreal <= ALIENSPARLIGNE ){
        x = (LARGEUR - info.nombreal) / 2;    
    }
    else{
        x = (LARGEUR - ALIENSPARLIGNE) / 2;
    }

    /**
    *mise en memoire de la variable permettant de mettre au centre ( sert plus tard )
    */
    int z = x;

    /**
    *boucle d'initalisation des aliens en fonctions de leurs nombres
    */
    for(i = 0; i < info.nombreal; i++){
        as[i] = initialiserAlien(x,y);

        /**
        *boucle permettant la mise des aliens au millieu des plateau quelque soit la largeur, le nombre d'aliens,
        *le nombre d'aliens par ligne et même si il y a un 'reste' d'alien à la fin
        */
        for (int j = 0; j<info.nombreal/ALIENSPARLIGNE+1;j++){
            if (i == ALIENSPARLIGNE*j-1){
                y++;
            if ( reste < ALIENSPARLIGNE){
                x = (LARGEUR - reste) / 2; 
            }
            else{
                    x = z-1;
                }
            }
        }
        reste = info.nombreal-i-1;
        x++;
    }

    /**  
    *retourne le nombre d'aliens
    */
    return info.nombreal;
}



 void afficherVaisseau(s_vaisseau c){ //méthode de vaisseau et alien
    /**
    *Afficchage des infos vaisseau
    */
	printf("VAISSEAU pos : %d, célérité : %d, tir : %c, tireEffectué : %c\n",c.posX,c.cel,c.tir,c.aTire);	 
 } 

 void afficherPlateau(s_vaisseau v,tab_aliens s, infopartie info){
    int y=0;
    /**
    *Affichage du plateau ligne par ligne
    */
    while (y != HAUTEUR+1){
        afficherLigne(y,v,s,info);
        y++;
    }
 }


 void afficherLigne(int y,s_vaisseau v,tab_aliens s, infopartie info){
    /**
    *Affichage des scores et des infos de la partie à la ligne 0
    */
    if ( y == 0){
        printf("SCORE : %d", info.score);
        for(int i = 0;i<ESPACE;i++)
        printf(" ");
        printf("NIVEAU : %d", info.level);
        for(int i = 0;i<ESPACE;i++)
        printf(" ");
        printf("VIE : %d", info.vie);
    }

    /**
    *Affichage des informations sur les tirs à la ligne 2
    */
    if ( y == 1){
        for (int x = 0;x<LARGEUR;x++){
            if(x == 0){
                int x;    
                if ( info.tirspe != 0){
                    x = TIRSPECIAL/10 - 0.1 * info.tirspe+1;
                }
                if ( info.tirspe >= TIRSPECIAL ){
                    printf("tir spécial Prêts !");
                }
                else{
                    printf("tir spécial : %d secondes", x);
                }      
                for(int i = 0;i<ESPACE;i++)
                printf(" ");
                if( v.tir == 's' ){
                    printf("Tir simple");
                }   
                if( v.tir == 'm' ){
                    printf("tir mortier");
                } 
                if( v.tir == 'd' ){
                    printf("double tir");
                }              
            }
        }
    }
    /**
    *Délimitation du plateau de jeu avec des '='
    */
    if ((y == 2) || (y == HAUTEUR)){
        for (y = 0;y != LARGEUR;y++)
            printf("=");
    }
    /**
    *Affichage de l'air de jeu
    */
    if ((y > 2) && (y < HAUTEUR)){
        int i = 0, print = 0;

        /**
        *Boucle vérifiant case par case la présence d'une entité ou non
        */
        for (int x = 0;x<LARGEUR;x++){

            /**  
            *Boucle vérifiant la présence d'un alien à la case actuelle
            *si c'est le cas imprime un @ représentant un alien
            */
            for(i = 0;i<(info.nombreal);i++)
                if(s[i].posY==y){
                    if(s[i].posX == x){
                        print=1;
                        printf("@");
                    }
                }

            /**  
            *Condition passante si un alien n'a pas été imprimé 
            */
            if ( print != 1 ) {

                /**  
                *Condition passante si le tir est actionner
                */
                if (v.aTire == 1){

                    /**  
                    *Condition passante si la case actuelle se trouve au niveau du vaisseau ( sur le même axe x )
                    */
                    if ((v.posX == x) && (y != (HAUTEUR-1))){
                        int c = 0;

                        /**  
                        *Condition passante si la case actuelle se trouve au niveau ou au dessus d'un alien
                        */
                        for (int a = 0;a<info.nombreal-1;a++)
                            if ((s[a].posX == x) && ((s[a].posY >= y) && (s[a].posY < 100))){
                                c = 1;
                            }

                        /**  
                        *Condition passante si l'on se trouve sur l'axe x du vaisseau et aucun n'alien n'est présent au dessus ou 
                        *à la case actuelle
                        */
                        if ( (c != 1) && (y>2)){
                            printf("|");
                            print = 1;
                        }
                    }
                }

                /**  
                *Condition passante si l'on se trouve sur à la hauteur du vaisseau
                */
                if (y == HAUTEUR-1){

                    /**  
                    *Condition passante si on se trouve sur à la case du vaisseau ( même axe x )
                    */
                    if(x == v.posX){
                        printf("#");
                        print = 1;
                    }
                }
            }

            /**  
            *Si aucune entité n'est présente, laisse une case vide
            */
            if ( print == 0 ){
                printf(" ");
            }
            print = 0;
        }      
    }

    /**  
    *Condition passante si le tir à été actionner et si la ligne se trouve à la hauteur du plateau - 1
    */
    if ((v.aTire == 1) && (y == HAUTEUR-1)){
        appliquerTir(v,s,info);
    }

    /**  
    *Passage à la prochaine ligne à chaque fin de ligne
    */
    printf("\n");
}


void deplacerAliens(tab_aliens s, infopartie info){ //méthode d'alien
    int reste, pas = 0, des = 0;

    /**  
    *Boucle permettant la verification de chaque aliens
    */
    for(int i = 0;i<=(info.nombreal-1);i++){

        /**  
        *Condition passante si un alien se trouve à la limite du plateau de jeu
        */
        if(s[i].posX == (LARGEUR-1)){
            des=1;
        }
    }

    /**  
    *Condition passante si un alien se trouve à la limite du plateau de jeu
    */
    if (des==1){
        int y = 0;

        /**  
        *Boucle permettant la verification de chaque aliens
        */
        for (int i=0;i <= (info.nombreal-1);i++){

            /**  
            *Condtion permattant de changer de ligne au moment ou ALIENSPARLIGNE est atteint
            */
            if ( y == ALIENSPARLIGNE ){
                    y = 0;
            }

            /**  
            *Condtion permattant d'afficher le reste d'alien au millieu de la nouvelle ligne
            */
            if ((i > y+info.nombreal-ALIENSPARLIGNE) && (pas != 1) && (info.nombreal > ALIENSPARLIGNE)){
                reste = info.nombreal-i;
                y = (ALIENSPARLIGNE-reste)/2;
                pas = 1;
            }

            /**  
            *Condtion permattant de passer à la ligne un alien ( si l'alien n'est pas hors-plateau donc mort )
            */
            if ( s[i].posX < LARGEUR){
                s[i].posY = s[i].posY + 1;
                s[i].posX = y;
            }
            y++;
        }
    }
    else{
        for(int i = 0;i <= (info.nombreal-1);i++)

            /**  
            *Condtion permattant de faire avancer chaque alien de 1 vers la droite
            */
            if ( s[i].posX < LARGEUR ){
                s[i].posX = s[i].posX + 1;
            }      
    }
}


void appliquerTir(s_vaisseau v, tab_aliens s, infopartie info){ //méthode de vaisseau et alien
    int nb = 0, hauteur = 0;

    /**  
    *Boucle permettant la verification de chaque aliens
    */
    for (int i = 0;i < (info.nombreal); i++){

        /**  
        *Condition passante si un alien se trouve à la même position x que le vaisseau
        */
        if ( s[i].posX == v.posX ){

            /**  
            *Condition passante si l'alien sélectionner est le plus bas sur le plateau ( boucle donc un autre alien encore plus bas peut repasser)
            */
            if ( s[i].posY > hauteur){
                nb = i;
                hauteur = s[i].posY;
            }
        }
    }

    /**  
    *Boucle permettant la verification de chaque aliens
    */
    for(int l = 0;l < (info.nombreal); l++)

        /**  
        *Condition passante si le tir sélectionner est le mortier 'm'
        */
        if ( v.tir == 'm'){

            /**  
            *Condition passante pour tous les aliens à la même hauteur que l'alien tué, tous les aliens
            *de la ligne sont tué
            */
            if ( s[l].posY == hauteur ){
                s[l].pv = s[l].pv - 1;
                if ( s[l].pv == 0 ){
                    s[l].posX = LARGEUR+1000;
                    s[l].posY = 100;
                }
            }
        }

        /**  
        *Condition passante si le tir sélectionner est le tir simple 's', tue l'alien ciblée
        */
        if ( v.tir == 's'){
            s[nb].pv = s[nb].pv - 1;
            if ( s[nb].pv == 0 ){
                s[nb].posX = LARGEUR+1000;
                s[nb].posY = 100;
                }
        }

        /**  
        *Condition passante si le tir sélectionner est le double tir 's', tue l'alien ciblée et l'alien au dessus si il est présent
        */
        if ( v.tir == 'd'){

            /**  
            *Boucle permettant la verification de chaque aliens
            */
            for(int m = 0;m < (info.nombreal); m++)

                /**  
                *Condition passante si les deux aliens sont à la même hauteur
                */
                if ( s[nb].posX == s[m].posX ){

                    /**  
                    *Condition passante si l'alien se situe juste au dessus de l'alien choisi
                    */
                    if ( s[nb].posY-1 == s[m].posY ){
                    s[m].pv = s[m].pv - 1;
                    if ( s[m].pv == 0 ){
                        s[m].posX = LARGEUR+1000;
                        s[m].posY = 100;
                    }
                    }
                }
                s[nb].pv = s[nb].pv - 1;
                if ( s[nb].pv == 0 ){
                    s[nb].posX = LARGEUR+1000;
                    s[nb].posY = 100;
                }
        }
}

int finPartie(tab_aliens s, infopartie info){ //méthode d'alien
    int a = 10;

    /**  
    *Boucle permettant la verification de chaque aliens
    */
    for(int b = 0;b<info.nombreal-1;b++)

        /**  
        *Condition passante si un alien se trouve à la hauteur du vaisseau
        */
        if(s[b].posY == (HAUTEUR-1)){
            a=2;
        }
    int count = 0;

    /**  
    *Boucle permettant la verification de chaque aliens
    */
    for( int i = 0;i<(info.nombreal);i++){

        /**  
        *Condition passante si un alien se trouve à x = largeur+10 ( mort )
        */
        if(s[i].posX > LARGEUR+10){
            count = count +1;
        }

        /**  
        *Condition passante si tous les alien se trouve à x = largeur+10, tous les aliens sont alors mort
        */
        if(count == (info.nombreal)){
            a=1;
        }
    }


    /**  
    *retourne l'état de la partie 
    */
    return a;
}

s_vaisseau actionVaisseau(char action, s_vaisseau v){  //méthode vaissaeu

    /**  
    *Si une action à été rentré, traduction de cette touche en action grâce à une des variable du vaisseau
    */
    if ( action != 'x' ){
        if ( action == 'm' ){ //m
            if (v.posX <= LARGEUR-2){
                v.posX=v.posX+1;
            }
        }
        if ( action == 'k' ){ //k
            if ( v.posX > 0 ){
                v.posX=v.posX-1;
            }
        }
        if ( action == 'o' ){ //o
            v.aTire = 1;
        }
        if ( action == 'i' ){ //i
            v.tir = 'm';
    
        }
        if ( action == 'j' ){ //j
            v.tir = 'd';
        }
        if ( action == 'p' ){ //p
            v.tir = 's';
        }
    }

    /**  
    *Retourne l'action à effectué
    */
    return v;
}

int actionDispo(){
	// la fonction retourne :
	// 1 si un caractere est present
	// 0 si pas de caractere présent
	int unCaractere=0;
	struct termios oldt, newt;
	int ch;
	int oldf;
 
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;

    newt.c_lflag &= ~(ICANON | ~ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
	ch = getchar();
 
	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);
 
	if(ch != EOF){
		ungetc(ch, stdin);
		unCaractere=1;
	} 
	return unCaractere;
} 

char recupererAction() 
{
    char ch = 'x';
    if(actionDispo()){
        ch = getchar();
        if(ch != 'm' && ch != 'k' && ch != 'o' && ch != 'q' && ch != 'i' && ch != 'j' && ch != 'p' && ch != 'e' && ch != 'u'){
            ch = 'x';
    	}
    }
    return ch;
}

