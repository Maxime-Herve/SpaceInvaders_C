/*!
* \file lanceur_spaceI.c
* \author Maxime HERVE et Yann MORIN <maximeholga@gmail.com>
* \version 2.0
* \date 30/11/2020
* \brief  Ce programme est un jeu nommé "Space Invader", le but du jeu est de tué des aliens qui apparaissent 
* au fur et à mesure de la partie. Si les aliens atteignent votre vaisseau et que vous n'avez plus de vie.
* Ce programme fonction à l'aide de fonction contenu dans spaceI.c et de constante et documentation contenu dans spaceI.h
* La beaucoup de paramètres du jeu son modifiable grace au constante dans spaceI.h 
* \remarks Ce programme à été ecrit pour un interpréteur de commande format 80X24, il se peut que l'affichage ne soit pas de la bonne taille sur un autre interpréteur de commande
* 
* 
* 
*/

/*! Importation of librairies*/
#include "spaceI.h"

int main(){
    printf("qsdf");
    /**
     *Creation et initialisation des variables nécessaire à la gestion du temps et des changements de level/fin de partie
     */
    int fin = 0, alientimer = 0, vaisseautimer = 0, shoottimer = 0, b = 1, count;
    char a = 'x';

    /**
    *Création des variables de type défini dans spaceI.h, servant à stocker les inforations vaisseau, aliens, et informations sur la partie
    */
    s_vaisseau mv;
    tab_aliens ta;
    infopartie info;

    /**
    *Initialisation des variables donnant les information nécessaire au démarrage de la partie
    */
    info.score = 0;
    info.vie = NBVIE;
    info.level = 1;
    info.tirspe = 0;

    /**
    *Boucle de démmarage du programe donnant la liste des commandes à l'utlisateur
    */
    while ( a != 'e'){
        if ( b == 1 ){
            for(int f = 0;f<12;f++)
            printf("\n");
            printf("                    Bienvenue dans le jeu Space Invader !\n");
            printf("\n");
            printf("  Pour lancer le jeu, appuyé sur e\n");
            printf("  Pour quitter le jeu, appuyé sur q\n");
            printf("\n");
            printf("  Voici les règles du jeu : des aliens apparaissent, \n");
            printf("  au fur et à mesure de la partie ils descendent vers votre vaisseau.\n");
            printf("  Le but est que les aliens n'atteignent pas \n");
            printf("  la ligne ( le niveau ) de votre vaisseau.\n");
            printf("  Pour vous protéger, vous posséder 3 types de tir. Vous possèdez aussi %d vies.\n", info.vie);
            printf("\n");
            printf("\n");
            printf("  Voici la liste des commandes :\n");
            printf("\n");
            printf("  Pour aller à gauche : k");
            printf("\n");
            printf("  Pour aller à droite : m");
            printf("\n");
            printf("  Pour tirer : o");
            printf("\n");
            printf("  Pour choisir le tir spécial Mortier : i");
            printf("\n");
            printf("  Pour choisir le tir spécial double tir : j");
            printf("\n");
            printf("  Pour choisir le tir simple : p");
            printf("\n");
            printf("  Pour faire une pause : u");

            for(int f = 0;f<2;f++)
            printf("\n");
            b = 0;
        }
        a = recupererAction();
        if ( a =='q'){
            return 0;
        }
    }

    a = 'x';

    /**
    *Initalisation des informations vaisseau et aliens
    */
    info.nombreal = initialiserAliensV2(ta, info);
    mv = initialiserVaisseau();

    /**
    *Boucle permettant l'actualisation, l'affichage et l'application de commande dans le jeu
    *Arret de la boucle si le programme est arréter ( q ).
    */
    while(a != 'q'){

        /**
        *Incrémantation des timer de chaque entité ( permet de gérer le temps avant chaque action )
        */
        alientimer++;
        shoottimer++;
        info.tirspe++;
        vaisseautimer++;

        /**
        *comptage du score dans le jeu
        */
        count = 0;
        info.score = 0;
        for( int i = 0;i<(info.nombreal);i++)
            if(ta[i].posX > LARGEUR+10){
                count = count +POINTPARALIENS;
            }

        for( int i = 1;i<(info.level);i++)
            info.score = i*NBALIENS*POINTPARALIENS+ info.score;
            
        info.score = info.score+count;

        /**
        *recuperation de l'action de l'utlisateur ( il peut ne pas y avoir d'action )
        */
        a = recupererAction();


        /**
        *Si U est pressé par l'utilisater mise en pause du jeu ( avec un affichage )
        */
        if ( a == 'u'){
            a = 'x';
            for(int f = 0;f<12;f++)
            printf("\n");
            printf("                    PAUSE, APPUYÉ SUR U POUR RELANCER");
            for(int f = 0;f<12;f++)
            printf("\n");
            while ( a != 'u'){
                a = recupererAction();
            }
            a ='x';
        }

        /**
        *Si le tir est actionner trop vite ( touche o ), remet l'action à aucune ( x )
        */
        if (shoottimer < VITESSETIR){
            if ( a == 'o'){
                a = 'x';
            }
        }

        /**
        *Si un tir "Special" est actionner trop vite ( touche i ou j ), remet l'action à aucune ( x )
        */
        if (info.tirspe < TIRSPECIAL){
            if ((a == 'i') || (a == 'j')){
                a = 'x';
            }
        }

        /**
        *Si un déplacement est actionner trop vite ( touche k ou m ), remet l'action à aucune ( x )
        */
        if ( vaisseautimer < mv.cel){
            if ((a == 'k') || (a == 'm')){
                a = 'x';
            }
        }

        /**
        *Si un déplacement est actionner, remet le timer déplacement à 0 ( pour refaire patienter l'utilisateur avant un nouveau déplacement )
        */
        if ((a == 'k') || (a == 'm')){
            vaisseautimer = 0;
        }

        /**
        *Si un tir est actionner, remet le timer tir à 0 ( pour refaire patienter l'utilisateur avant un nouveau tir )
        */
        if (a == 'o'){
            shoottimer = 0;
        }

        /**
        *Si une touche est actionné, traduction de cette touche en une action ( modification d'une variable vaisseau )
        */
        for(int f = 0;f<20;f++)
        printf("\n");
        if (a != 'x'){
            mv = actionVaisseau(a,mv);
        }

        /**
        *Actualise l'affichage
        */
        afficherPlateau(mv,ta, info);

        /**
        *Si le timer de l'alien arrive à sa vite de déplacement ( vitesse défini dans le temps ), déplace les aliens
        *Relance le timer des aliens
        */
        if ( alientimer == ta[0].cel){
            alientimer = 0;
            deplacerAliens(ta, info);
        }
        
        /**
        *Remet l'action du tir à 0( qui à été modifier par actionVaisseau(); )
        */
        mv.aTire = 0;

        /**
        *Remet le type de tir à simple après avoir tiré ( qui à été modifier par actionVaisseau(); )
        *Relance le timer de tir spécial
        */
        if (((a == 'o') && (mv.tir == 'm')) || ((a == 'o') && (mv.tir == 'd'))){
            info.tirspe = 0;
            mv.tir = 's';
        }

        /**
        *Vérifie la fin d'un level / la mort de vaisseau
        */

        /**
        *Vérifie la fin d'un level / la mort de vaisseau
        */
        fin = finPartie(ta, info);

        /**
        *Si le level est terminé ( fin == 1 retourné par finPartie(); ), indication de passage au level suivant 
        *et réinitialisation du vaisseau et des aliens à leurs nouveau level
        */
        if ( fin == 1 ){
            info.level = info.level + 1;
            for(int f = 0;f<12;f++)
            printf("\n");
            printf("                    PASSAGE AU LEVEL %d!", info.level);
            for(int f = 0;f<12;f++)
            printf("\n");
            info.nombreal = initialiserAliensV2(ta, info);
            mv = initialiserVaisseau();
            usleep(PAUSE*20);
        }

        /**
        *Si le vaisseau est mort ( fin == 2 retourné par finPartie(); ), indication de la mort et retire une vie
        */
        if (fin == 2){
            info.vie = info.vie - 1;

            /**
            *Si le vaisseau vaisseau a encore de la vie, affiche le message il reste x vie
            */
            if ( info.vie != 0 ){
                for(int f = 0;f<12;f++)
                printf("\n");
                printf("                    VOUS ETES MORT, IL VOUS RESTE %d VIE!", info.vie);
                for(int f = 0;f<12;f++)
                printf("\n");
                initialiserAliensV2(ta, info);
                mv = initialiserVaisseau();
                usleep(PAUSE*20);
            }
        }

        /**
        *Si le vaisseau est mort ( fin == 2 retourné par finPartie(); ), indication de la mort et affichage
        *du score, du nombre d'aliens tués et du level survécu
        */
        if ( info.vie == 0){
            for(int f = 0;f<12;f++)
            printf("\n");
            int alien = info.score/POINTPARALIENS;
            printf("                    FIN DE LA PARTIE! VOUS AVEZ PERDU!\n");
            printf("                         VOTRE SCORE ÉTAIT DE %d\n", info.score);
            printf("                     VOUS AVEZ TUÉ %d ALIENS AU TOTAL\n", alien);
            printf("                    VOUS AVEZ SURVECU JUSQU'AU LEVEL %d\n", info.level);
            for(int f = 0;f<12;f++)
            printf("\n");
            return 0;
        }

        /**
        *horloge du programme qui s'actualise tous les PAUSE ( voir spaceI.h )
        */
        usleep(PAUSE); 
    }

    /**
    *Si l'utilisateur vient de quitter, indication de fin de partie avec infos
    */
    for(int f = 0;f<12;f++)
    printf("\n");
    int alien = info.score/POINTPARALIENS;
    printf("                    FIN DE LA PARTIE! VOUS AVEZ QUITTER!\n");
    printf("                         VOTRE SCORE ÉTAIT DE %d\n", info.score);
    printf("                     VOUS AVEZ TUÉ %d ALIENS AU TOTAL\n", alien);
    for(int f = 0;f<12;f++)
    printf("\n");
    return 0;
}
