/*!
* \file spaceI.h
* \author Maxime HERVE et Yann MORIN <maximeholga@gmail.com>
* \version 2.0
* \date 30/11/2020
* \brief Spécification des fonctions de spaceI.c, diverse constante essentielle au bon fonctionnement du programme, initialisation de variable 
* 
* 
* 
*/


#ifndef __SPACEI_H__
#define __SPACEI_H__

/*! Importation de librairies*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <fcntl.h>



/*!
* \def HAUTEUR
* hauteur total du plateau
*/
#define HAUTEUR 20

/*!
* \def LARGEUR
* largeur total du plateau
*/
#define LARGEUR 40

/*!
* \def ESPACE
* espace modifiable entre chaque info dans l'affichage des score et infos de la partie
*/
#define ESPACE 7


/*!
* \def PAUSE
* temps entre chaque actualisation du programme en micro-seconde
*/
#define PAUSE 100000

/*!
* \def VITESSEAL
* vitesse de l'alien par rapport au temps de pause
*/
#define VITESSEAL 1

/*!
* \def VITESSEVS
* vitesse du vaisseau par rapport au temps de pause
*/
#define VITESSEVS 1

/*!
* \def VITESSETIR
* vitesse entre chaque tir par rapport au temps de pause
*/
#define VITESSETIR 5

/*!
* \def TIRSPECIAL
* vitesse entre chaque tir spécial par rapport au temps de pause
*/
#define TIRSPECIAL 50


/*!
* \def NBALIENS
* nombre d'aliens au démarrage
*/
#define NBALIENS 16


/*!
* \def ALIENSPARLIGNE
* nombre d'alien par ligne
*/
#define ALIENSPARLIGNE 20


/*!
* \def NBVIE
* nombre de vie du vaisseau
*/
#define NBVIE 3


/*!
* \def NBVIEAL
* nombre de vie des aliens
*/
#define NBVIEAL 1


/*!
* \def POINTPARALIENS
* nombre de point par alien tué
*/
#define POINTPARALIENS 5


/**
 * Structures du vaisseau contenant la position X, la vitesse, le type de tir et l'action du tir
 */
 struct s_vaisseau {

    /**
     *Variable contenant la position X du vaisseau
     */
     int posX;

    /**
     *Variable contenant la vitesse du vaisseau ( temps de pause )
     */
     int cel;

    /**
     *Variable contenant le type de tir du vaisseau
     */
     char tir;

    /**
     *Variable contenant l'état du tir ( actionné ou non )
     */
     int aTire; 
 };

 /**
 * Structures de l'alien contenant la position X, la position Y, la vitesse et les pv de l'alien
 */
 struct s_alien{

    /**
     *Variable contenant la position X d'un alien
     */
     int posX;

    /**
     *Variable contenant la position Y d'un alien
     */
     int posY;

    /**
     *Variable contenant la vitesse d'un alien ( temps de pause )
     */
     int cel;

    /**
     *Variable contenant les PV d'un alien
     */
     int pv;
 };

 /**
 * Structures 'infopartie' contenant le score, le level, la vie du vaisseau, le nombre d'alien et le timer entre chaque tir spécial
 */
struct infopartie{

    /**
     *Variable contenant le score de la partie
     */
     int score;

    /**
     *Variable contenant le niveau de la partie
     */
     int level;

    /**
     *Variable contenant la vie restante du vaisseau
     */
     int vie;

    /**
     *Variable contenant l'information sur le nombre d'alien
     */
     int nombreal;

    /**
     *Variable contenant le timer du tir spécial
     */
     int tirspe;
 };
 
 /**
 *création d'un type de variable de type s_vaisseau
 */
 typedef struct s_vaisseau s_vaisseau;


 typedef struct s_alien s_alien;

/**
 *création d'un type de variable de type infopartie
 */
 typedef struct infopartie infopartie;

/**
 *création d'un type de variable de type s_alien[Nombre d'alien total max]
 */
 typedef s_alien tab_aliens[(ALIENSPARLIGNE*HAUTEUR)];


/** Procédure réalisant l'affichage d'un vaisseau
*@param v_vaisseau une structure de type v_vaisseau à afficher
*/
 void afficherVaisseau(s_vaisseau) ;

/** Fonction qui initialise une nouvelle structure de type s_vaisseau. La position du vaisseau est par défaut le milieu du plateau (i.e. LARGEUR / 2) où LARGEUR est constante symbolique définie dans spaceI.h. La vitesse par défaut du vaisseau est de 1, signifiant qu’il se déplace d’une case à chaque mouvement. Parmi les différents tirs disponibles (‘s’ -> simple, ‘d’ -> double, ‘t’-> triple et ‘m’ -> mortier), son type par défaut est ‘s’.
*@return v_vaisseau une structure de type v_vaisseau
*/
s_vaisseau initialiserVaisseau() ;

/** Fonction qui initialise une nouvelle structure de type s_alien. Les positions en x et en y de l’alien sont passées en paramètres de la fonction. Sa vitesse de déplacement est par défaut 1, ses points de vie à 1 dans la V1 du jeu.
*@param int x la position en x de l’alien
*@param int y la position en y de l’alien
*@return s_alien une structure de type s_alien
*/
s_alien initialiserAlien(int x, int y) ;


/** Procédure qui initialise un tableau d’aliens passé en paramètre. Ce tableau est de type tab_aliens (voir étape 1) et est directement modifié dans la procédure (normal, on ne peut pas retourner de tableau depuis une fonction). 
Dans la V1 du jeu les aliens sont positionnés 
*@param tab_aliens un tableau de NBALIENS structures de type s_alien
*/
void initialiserAliens(tab_aliens as) ;

/** Procédure qui initialise un tableau d’aliens passé en paramètre. Ce tableau est
de type tab_aliens (voir étape 1) et est directement modifié dans la procédure
(normal, on ne peut pas retourner de tableau depuis une fonction). Dans la V1 du jeu les aliens sont positionnés
*@param tab_aliens un tableau de NBALIENS structures de type s_alien *@param infopartie les infos sur la partie
*/
int initialiserAliensV2(tab_aliens , infopartie ) ;

/**
* Affiche le plateau de jeu, le vaisseau et les . * @param s_vaisseau le vaisseau du jeu
* @param tab_aliens le tableau des aliens du jeu * @param infopartie les infos sur la partie*/
void afficherPlateau(s_vaisseau,tab_aliens, infopartie);

/**
* Cette procédure affiche la ligne l du plateau de jeu * @param int la ligne à afficher
* @param s_vaisseau le vaisseau du jeu
* @param tab_aliens le tableau des aliens du jeu
* @param infopartie les infos sur la partie
**/
void afficherLigne(int y,s_vaisseau,tab_aliens,infopartie);

/**
* Fonction modifiant un vaisseau par rapport à l'action
* passée en premier paramètre ((‘g’ pour gauche, ‘d’ pour droite, ‘t’ pour tir) * @param char l'action à effectuer
* @param s_vaisseau le vaisseau à modifier
* @return le vaisseau modifié
**/
s_vaisseau actionVaisseau(char action, s_vaisseau);

/**
* Procédure effectuant le déplacement des aliens présents * dans le tableau tab_aliens.
* @param tab_aliens le tableau des aliens à déplacer
* @param infopartie les infos sur la partie
**/
void deplacerAliens(tab_aliens mv, infopartie);

/**
* Cette fonction détermine si le jeu est terminé. * @param tab_aliens le tableau des aliens
* @param infopartie les infos sur la partie
*/
int finPartie(tab_aliens, infopartie);

/**
* Procédure vérifiant si le tir effectué par le vaisseau * touche un des aliens. Dans ce cas, il est mort.
* @param s_vaisseau le vaisseau du jeu
* @param tab_aliens le tableau des aliens du jeu *
* @param infopartie les infos sur la partie
*/
void appliquerTir(s_vaisseau, tab_aliens,infopartie);

/**
 * Fonction récupérant l'action choisie par le joueur
 * Par défaut les touches 'k' pour gauche - 'm' pour droite et 'o' pour tirer.
 * 'q' pour quitter le jeu.
 *  @return char un caractère représentant l'action à appliquer : 't' -> tir, 'g' -> gauche, 'd' -> droite, 'x' -> passer le tour, 'q' -> quitter
 **/     
char recupererAction(); 

/**
 * Fonction testant si un caractère est disponible dans le flux stdin (fonction utilisée par getAction())
 *  @return int 0 ou 1
 **/     
int actionDispo();


#endif